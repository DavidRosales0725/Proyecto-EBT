"""
Cálculo de probabilidades de mercado vía distribución de Poisson.
"""
import math
from dataclasses import dataclass
from scipy.stats import poisson
from core.expected_goals import GolesEsperados


@dataclass
class ProbabilidadesMercado:
    over_05: float
    under_05: float
    over_15: float
    under_15: float
    over_25: float
    under_25: float
    over_35: float
    under_35: float
    btts_si: float
    btts_no: float


def _prob_under(k: int, lam_total: float) -> float:
    """P(goles totales <= k) usando la CDF de Poisson."""
    return poisson.cdf(k, lam_total)


def calcular_probabilidades(goles: GolesEsperados) -> ProbabilidadesMercado:
    lam_total = goles.lambda_local + goles.lambda_visitante

    under_05 = _prob_under(0, lam_total)
    under_15 = _prob_under(1, lam_total)
    under_25 = _prob_under(2, lam_total)
    under_35 = _prob_under(3, lam_total)

    btts_si = (1 - math.exp(-goles.lambda_local)) * (1 - math.exp(-goles.lambda_visitante))

    return ProbabilidadesMercado(
        over_05=1 - under_05, under_05=under_05,
        over_15=1 - under_15, under_15=under_15,
        over_25=1 - under_25, under_25=under_25,
        over_35=1 - under_35, under_35=under_35,
        btts_si=btts_si, btts_no=1 - btts_si,
    )
