"""
conftest.py

Permite que pytest descubra e importe los módulos del proyecto (data_loader,
historicos, backtesting, core/, decision/, etc.) sin necesidad de rutas
hardcodeadas en cada archivo de test. pytest carga este archivo
automáticamente antes de recolectar pruebas, sin importar desde qué
directorio de trabajo se invoque `pytest`.

La ruta se calcula de forma relativa a la ubicación de este propio archivo,
no a una ruta absoluta fija -- por eso el proyecto funciona igual si se
clona o se mueve a cualquier otra carpeta o máquina.
"""
import sys
from pathlib import Path

RAIZ_PROYECTO = Path(__file__).resolve().parent
if str(RAIZ_PROYECTO) not in sys.path:
    sys.path.insert(0, str(RAIZ_PROYECTO))
