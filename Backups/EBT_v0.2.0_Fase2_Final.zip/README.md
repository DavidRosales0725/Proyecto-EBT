# EBT — Motor de Predicción Estadística de Fútbol

Motor de predicción estadística para mercados de goles (Over/Under, BTTS)
en fútbol, basado en distribución de Poisson y ponderación exponencial de
forma reciente. El sistema es, ante todo, un **motor de predicción**: el
Value Bet es una consecuencia derivada del motor, no su objetivo principal.

Estado actual: **Fase 2 cerrada** (validación con datos reales completa).
Ver `ROADMAP.md` para el estado detallado por fase y `CHANGELOG.md` para
el historial de cambios.

## Instalación

```bash
pip install -r requirements.txt
```

Requiere Python 3.10+.

## Estructura del proyecto

```
EBT/
├── data_loader.py       # Importación y limpieza de CSVs históricos reales
├── historicos.py        # Contextos históricos "punto en el tiempo" (anti-leakage)
├── backtesting.py        # Evaluación retrospectiva del motor sobre temporadas reales
├── tipos_comunes.py     # Tipos de datos compartidos entre capas
│
├── core/                 # Motor estadístico puro (Poisson, Dixon-Coles, fuerzas, λ)
├── decision/              # Value Bet (consumidor del motor, no parte de él)
├── evaluacion/            # Scripts de validación por simulación (Fase 1)
│
├── examples/              # CSVs de ejemplo (reales y sintéticos) para pruebas
├── tests/                 # Suite de pruebas (pytest)
├── conftest.py             # Resolución de imports para pytest, sin rutas hardcodeadas
└── requirements.txt
```

## Arquitectura en capas

```
Datos → Preparación → Motor → Decisión → Evaluación
```

- **Preparación**: `data_loader.py`, `historicos.py`
- **Motor**: `core/` (fuerzas, λ, Poisson/Dixon-Coles) — estadística pura,
  no conoce cuotas ni dinero
- **Decisión**: `decision/value_bet.py` — probabilidad implícita, value,
  overround
- **Evaluación**: `backtesting.py` — orquesta las capas anteriores sobre
  datos históricos reales, con garantía anti-data-leakage

Regla de dependencia: cada capa solo puede importar de las capas
anteriores en esa lista, nunca al revés. Verificado sin excepciones en
todo el código actual.

## Ejecutar las pruebas

```bash
pytest tests/ -v
```

Funciona desde cualquier directorio de trabajo — no hay rutas
hardcodeadas en ningún archivo del proyecto.

## Uso básico

```python
from data_loader import cargar_datos
from backtesting import ejecutar_backtesting, ConfiguracionBacktesting, imprimir_resumen

datos = cargar_datos("examples/E0_real.csv")
resultado = ejecutar_backtesting(datos.df, ConfiguracionBacktesting())
imprimir_resumen(resultado)
```

## Principios de diseño

1. **Motor de predicción, no programa de apuestas.** El Value Bet es
   consecuencia del motor, físicamente separado en `decision/`.
2. **Nunca caja negra.** Cada predicción es trazable a las fuerzas,
   λ y forma reciente que la produjeron.
3. **Validación antes que interfaz.** No existe interfaz gráfica todavía
   — deliberado, hasta confirmar capacidad predictiva real con datos
   reales (ya confirmado parcialmente en la Fase 2, ver `CHANGELOG.md`).
4. **Ninguna conclusión sin evidencia cuantitativa.** Toda decisión de
   diseño (α, tamaño de histórico, uso de Dixon-Coles) fue sometida a
   prueba antes de adoptarse.
5. **Garantía anti-data-leakage por diseño, no por convención.** `fecha_corte`
   es un parámetro obligatorio sin valor por defecto en `historicos.py`;
   verificado con pruebas de propiedad automatizadas.
