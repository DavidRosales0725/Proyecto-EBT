# Roadmap — Proyecto EBT

## FASE 1 — Motor Estadístico
**Estado: ✅ Completada**

Ponderación exponencial, fuerzas ofensiva/defensiva relativas, goles
esperados, probabilidades de mercado vía Poisson, corrección Dixon-Coles
(implementada, no activada por defecto), Value Bet, métricas de
calibración. Validado exhaustivamente por simulación controlada.

## FASE 2 — Validación con Datos Reales
**Estado: ✅ Completada**

- `data_loader.py`: importación y limpieza de CSVs reales, validado contra
  una temporada completa de Premier League.
- `historicos.py`: contextos históricos "punto en el tiempo" con garantía
  anti-data-leakage formal (tres niveles de protección + test de
  propiedad automatizado).
- `backtesting.py`: evaluación retrospectiva completa — predicciones,
  apuestas simuladas, métricas de calibración y financieras, exportación
  CSV. Validado sobre datos reales de punta a punta.
- Auditoría técnica completa realizada; hallazgos críticos (rutas
  hardcodeadas, empaquetado) corregidos en el cierre de fase.
- Reorganización arquitectónica en capas ejecutada
  (`decision/`, `evaluacion/`, `examples/`).

### Pendiente explícitamente diferido a fases posteriores
(registrado, no descartado — ver `CHANGELOG.md` y las auditorías previas
para el detalle completo de cada punto)

- Resolución de nombres de equipo inconsistentes entre temporadas.
- Validación de rendimiento a escala (20 temporadas / 50 ligas /
  100 000 partidos) — el bootstrap y el bucle principal de `backtesting.py`
  fueron optimizados para el volumen actual (~380-1000 partidos), pero no
  se han probado a esa escala mayor.
- Separación de `version_modelo` (Poisson puro / Dixon-Coles) en un
  registro extensible, consistente con el patrón ya usado para mercados.
- División de `backtesting.py` en módulos más pequeños por responsabilidad.
- Validación de contenido (no solo existencia) de columnas de cuotas al
  resolver la casa configurada.

## FASE 3 — Interfaz
**Estado: ⚪ No iniciada**

Pausada deliberadamente hasta este punto. Con la Fase 2 cerrada y el motor
validado con datos reales (aunque sin edge estadístico confirmado
todavía), este es el primer punto del proyecto donde construir una
interfaz deja de ser prematuro. Sin diseño ni mockups todavía.

## FASE 4 — Validación Final
**Estado: ⚪ No iniciada**

Depende de acumular más temporadas/ligas reales para que el ROI y la
calibración segmentada tengan suficiente evidencia estadística (el
intervalo de confianza del ROI medido en Fase 2 cruza cero — no hay
edge confirmado todavía, ni descartado).

## Fuera de alcance de las Fases 1-4 (ideas registradas para versiones futuras)

Scanner Diario, explicación de predicciones en lenguaje natural, dashboard,
exportación PDF/Excel, configuración avanzada expuesta al usuario, Machine
Learning como alternativa/complemento a Poisson, integración con APIs
deportivas en vivo, fuentes de datos con xG real, Kelly Criterion / stake
dinámico, CLV con cuotas de cierre, optimizador automático de
hiperparámetros con partición temporal 60/20/20 (diseñado conceptualmente
en la Fase 2, no implementado).
