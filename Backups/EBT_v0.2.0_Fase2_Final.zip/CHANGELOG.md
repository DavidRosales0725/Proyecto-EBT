# Changelog

## [Fase 2] — Validación con datos reales — CERRADA

### Añadido
- `data_loader.py`: importación y preparación de CSVs históricos reales,
  con detección automática de columnas por sinónimos, limpieza con motivo
  de descarte explícito, y conservación de todas las columnas originales
  del CSV (incluidas cuotas) junto a las columnas estandarizadas.
- `historicos.py`: contextos históricos "punto en el tiempo" con garantía
  anti-data-leakage en tres niveles (interfaz, filtro estricto, test de
  propiedad automatizado). Filtro por liga obligatorio. Campo
  `confianza_historico` ("alta"/"media"/"baja").
- `tipos_comunes.py`: `ResultadoPartido` extraído de `core/fuerzas.py` a un
  módulo neutral, para que Preparación no dependa de Motor.
- `backtesting.py`: evaluación retrospectiva completa del motor sobre
  temporadas reales — registro de predicciones, registro de apuestas
  simuladas, partidos excluidos con motivo, métricas de calibración
  (Brier Score, Log Loss, Hit Rate) y financieras (ROI, Yield, drawdown,
  rachas, valor esperado), intervalos de confianza por bootstrap (por
  partido, no por fila), exportación a CSV.
- `decision/value_bet.py`: probabilidad implícita, value, overround
  (movido desde `core/`, ver "Cambiado").
- Suite de pruebas: 35 pruebas (14 de `historicos.py`, 21 de
  `backtesting.py`), incluyendo pruebas de propiedad anti-leakage,
  equivalencia contra fuerza bruta, y un test de integración completo
  sobre la temporada real de Premier League 2024-25.

### Cambiado
- `value_bet.py` movido de `core/` a `decision/` — separa físicamente el
  motor de predicción puro de sus consumidores (principio "motor de
  predicción, no programa de apuestas").
- Scripts de validación de Fase 1 (`validar_motor.py`,
  `barrido_validacion.py`, `barrido_alpha_dinamico.py`) movidos de la
  raíz del proyecto a `evaluacion/`.
- CSVs de prueba movidos de `tests_data_loader/` a `examples/`.
- Todas las rutas hardcodeadas (`sys.path.insert` con ruta absoluta fija)
  reemplazadas por rutas dinámicas relativas a la ubicación de cada
  archivo, o resueltas vía `conftest.py` para pytest. El proyecto ahora
  funciona desde cualquier directorio de trabajo — verificado ejecutando
  la suite completa desde una carpeta ajena al proyecto.

### Corregido
- Bug: el mensaje de error de `data_loader.ErrorColumnasFaltantes` mostraba
  las columnas faltantes en vez de las columnas disponibles del CSV.
- Bug de rendimiento: `_bootstrap_ic_brier()` y `_bootstrap_ic_roi()` en
  `backtesting.py` usaban `pd.concat()` de DataFrames en cada uno de los
  1000 remuestreos por segmento (>100s proyectados sobre datos reales).
  Reescrito con arrays de NumPy precalculados y operaciones vectorizadas,
  preservando exactamente la misma secuencia de muestreo aleatorio
  (resultado matemáticamente idéntico, verificado bit a bit). Tiempo total
  del backtesting sobre una temporada real: de >100s (timeout) a ~2s.

### Hallazgos de la validación con datos reales (Premier League 2024-25)
- Con los defaults (α=0.90, 15 partidos de histórico, sin cruzar
  temporadas), solo 176/380 partidos (46.3%) alcanzan histórico suficiente
  en ambos lados — medido de forma independiente por `historicos.py` y
  confirmado por `backtesting.py`.
- Brier Score global: 0.194 (IC 95%: 0.178–0.209).
- Curva de calibración: el modelo muestra sobreconfianza en probabilidades
  altas (>70%) — mismo patrón cualitativo ya observado en las simulaciones
  de Fase 1, ahora confirmado con datos reales.
- ROI sobre 68 apuestas simuladas (único mercado con cuotas reales
  disponibles en el dataset: Over/Under 2.5): -8.79%, IC 95%
  (-30.7%, +12.0%) — el intervalo cruza cero, sin evidencia estadística de
  edge real todavía.
- football-data.co.uk solo publica cuotas de Over/Under 2.5 de forma
  estándar; los demás mercados (0.5, 1.5, 3.5, BTTS) son evaluables para
  calibración pero no para Value Bet con este dataset.

## [Fase 1] — Motor estadístico — CERRADA

### Añadido
- `core/pesos.py`, `core/fuerzas.py`, `core/expected_goals.py`,
  `core/poisson_model.py`: motor de predicción (ponderación exponencial,
  fuerza ofensiva/defensiva relativa, goles esperados, probabilidades de
  mercado vía Poisson).
- `core/dixon_coles.py`: corrección de correlación en marcadores bajos,
  implementada pero no activada por defecto.
- `core/value_bet.py` (posteriormente movido a `decision/`): probabilidad
  implícita, value, overround.
- `core/metrics.py`: Brier Score, Log Loss, hit rate.
- Validación exhaustiva por simulación controlada: universo de equipos con
  fuerzas verdaderas conocidas, barrido de α × tamaño de histórico,
  comparación Poisson puro vs. Dixon-Coles.

### Hallazgos de la validación por simulación
- El motor mejora sobre un modelo ingenuo (7-14% en Brier Score) solo
  cuando hay dispersión de calidad realista entre equipos.
- No existe un α universal: depende de la volatilidad real de forma de
  los equipos.
- Dixon-Coles no mostró mejora significativa con el tamaño de muestra de
  Fase 1 (15-20 partidos) — documentado como mejora diferida, no activada
  por defecto.
